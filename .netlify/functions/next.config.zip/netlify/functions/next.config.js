"use strict";

// netlify/functions/next.config.js
module.exports = {
  // Desativa a otimização de imagens no Netlify
  images: {
    loader: "imgix",
    path: ""
  },
  // Configurações de compilação
  compiler: {
    // Habilita a minificação
    removeConsole: process.env.NODE_ENV === "production"
  },
  // Configurações de geração estática
  target: "serverless",
  // Configurações de headers
  async headers() {
    return [
      {
        // Aplica esses headers a todas as rotas da API
        source: "/api/:path*",
        headers: [
          { key: "Access-Control-Allow-Credentials", value: "true" },
          { key: "Access-Control-Allow-Origin", value: "*" },
          { key: "Access-Control-Allow-Methods", value: "GET,OPTIONS,PATCH,DELETE,POST,PUT" },
          { key: "Access-Control-Allow-Headers", value: "X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version" }
        ]
      }
    ];
  },
  // Configurações de redirecionamento
  async redirects() {
    return [
      {
        source: "/",
        destination: "/dashboard",
        permanent: true
      }
    ];
  },
  // Configurações de reescrita
  async rewrites() {
    return [
      {
        source: "/api/:path*",
        destination: "/.netlify/functions/:path*"
      }
    ];
  }
};
