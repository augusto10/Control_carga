"use strict";

// netlify/functions/prisma.js
var { PrismaClient } = require("@prisma/client");
process.env.PRISMA_SCHEMA_PATH = require("path").resolve(__dirname, "../../prisma/schema.prisma");
var prisma = global.prisma || new PrismaClient({
  log: ["query", "info", "warn", "error"]
});
if (process.env.NODE_ENV !== "production") {
  global.prisma = prisma;
}
module.exports = prisma;
